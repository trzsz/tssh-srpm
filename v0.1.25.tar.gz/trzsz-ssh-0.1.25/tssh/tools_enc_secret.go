/*
MIT License

Copyright (c) 2023-2026 The Trzsz SSH Authors.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

package tssh

import (
	"fmt"

	"charm.land/lipgloss/v2"
)

func execEncodeSecret() (int, bool) {
	state, err := makeStdinRaw()
	if err != nil {
		toolsErrorExit("make stdin raw failed: %v", err)
	}
	addOnExitFunc(func() { resetStdin(state) })

	secret := promptPassword("Password or secret to be encoded", "",
		&inputValidator{func(secret string) error {
			if secret == "" {
				return fmt.Errorf("empty password or secret")
			}
			return nil
		}})
	encoded, err := encodeSecret([]byte(secret))
	if err != nil {
		toolsErrorExit("encode secret failed: %v", err)
	}
	fmt.Printf("%s%s%s\r\n\r\n",
		lipgloss.NewStyle().Foreground(greenColor).Render("Encoded secret for configuration"),
		lipgloss.NewStyle().Faint(true).Render(": "), encoded)
	return 0, true
}
